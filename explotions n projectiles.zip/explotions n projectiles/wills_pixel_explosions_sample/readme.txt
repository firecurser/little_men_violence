//////////
//THANKS//
//////////

Hi there, this is Will from unTied Games! Nice to meet you.

Super huge THANK YOU for downloading this asset... It means a lot to me that you've chosen it for your game!
If you use this asset in your game, give me a shoutout if you can at @untiedgames, so I can follow along on your development journey!
Want to follow me? Sign up for my newsletter! Or follow me using the Twitter / FB / Youtube links below.
Newsletter signup: http://untiedgames.com/signup

Did you know? You can get access to ALL of my assets if you support me on Patreon!
Check it out: http://patreon.com/untiedgames
You read that right! At the $10 tier, you can get access to ALL of my assets. Not your cup of tea? At the $5 tier, you can get access to all my assets that are 1 year old or more. There's also a lot more than just pixel art... I make Youtube videos, indie games, development logs, and more!

MORE LINKS:
Browse my other assets: untiedgames.itch.io/
Watch me make pixel art, games, and more: youtube.com/c/unTiedGamesTV
Follow on Facebook: facebook.com/untiedgames
Follow on Twitter: twitter.com/untiedgames
Visit my blog: untiedgames.com

Thanks again,
- Will

/////////////////////////
//HOW TO USE THIS ASSET//
/////////////////////////

Hello, fellow game developer! Thank you for downloading the free sample version of Will's Pixel Explosions. Here are a few pointers to help you navigate and make sense of this zip file.

---TIPS AND TRICKS---

- In the main folder, you'll see 1 folder for each animation. I've tried to name them as descriptively as I can!

- In each animation folder, you'll find a "PNG" folder. This is where the individual frames of the animation are.

- In each animation folder, you'll also find a folder called "spritesheet." In this folder is all the individual frames packed into one image. The accompanying text file is metadata describing where each frame is on the spritesheet.
The metadata format is:
(frame name) = x y width height

- Want more? The full pack includes 10 explosion animations, with 4 color styles each. That's 40 explosions total!
Buy the full pack here: https://untiedgames.itch.io/wills-pixel-explosions

---FRAME DURATIONS---

Each animation has specific durations for each frame, measured in milliseconds.
Fortunately, this asset pack is easy: They're all 60 FPS animations! That means 16.67 milliseconds per frame.

---FINAL THOUGHTS---

Got questions? Hit me up at:
@untiedgames (twitter)
contact@untiedgames.com (email)

Thanks again! Check out more of my asset packs at https://untiedgames.itch.io.
-Will
