Hi game developer
	
Thanks for downloading this asset I really hope you find good use for it in your project. 
	
   I produced this asset for my site http://www.gamedeveloperudio.com  as a game developer you might find it useful. You'll find more free assets there  as well as very  affordable assets too.
	
   I'm trying to create a huge library of 2d game assets. I started work on it in 2015 and now at the time of writing this have over easily 1000 assets available and that's not including colour variations of the same asset or tile set variations! I'm creating all the assets myself so there's more or less the same art style across the whole library.
   
The best thing about the library apart from the quality is it's affordability, I want this project to be available to all developers, those who do it for a living, those who do it for fun or those that don't really make money out of there games. Not everybody  has a big budget for creating their game, why shouldn't they have access to quality royalty free assets they can use in their projects!  
	
   If you want to support the project why not check out site! I don't ask for donations but if you see something you like there why not consider paying for some of the assets.  Developers who pay help fund more free and affordable assets by covering my server and development costs. 
	
If like the idea please spread the word! www.gamedeveloperstudio.com
	
Thanks for reading!
	
Robert Brooks
	

	
	
