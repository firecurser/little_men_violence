Thank you very much for downloading the assets. 

A Set of 2D Pixel Art Sprites. Includes sprites of specific actions, including shooting animations: 
	Idle
	Running (including shooting)
	Jumping (including shooting)
	Shooting (including shooting)
	Taking Damage (including shooting)
	Dying

Sprites created using Adobe Photoshop CC. Feel free to use these assets in your commercial game. 

If you have any questions feel free to contact me via the E-Mail below:
gh.gamedev@hotmail.com

Sprites made by G. Herzog

Copyright G. Herzog, permission to use in commercial projects