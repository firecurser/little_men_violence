### Rodent Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/82869)

By [Tuomo Untinen (Reemax)](https://opengameart.org/users/Reemax):
- [[LPC] Rat, Cat and Dog](https://opengameart.org/node/39573) (CC BY 3.0 / CC BY-SA 3.0)
